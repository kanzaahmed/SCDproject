import static org.junit.Assert.*;

import org.junit.Test;

public class Testing {

	@Test
	public void test() {
		Car sc=new Car();
		int output1=sc.years(1200);
		assertEquals(1200, output1);
	}

}
