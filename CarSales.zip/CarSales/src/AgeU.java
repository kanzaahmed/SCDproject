import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AgeU {

	@Test
	void test() {
		Car sc=new Car();
		int output1=sc.getAge();
		assertEquals(2021, output1);
	
	}

}
